package com.example.submitssionform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SubmitssionFormApplication {

    public static void main(String[] args) {
        SpringApplication.run(SubmitssionFormApplication.class, args);
    }

}
