package com.example.submitssionform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubmitssionFormApplicationTests {

    @Test
    void contextLoads() {
    }

}
